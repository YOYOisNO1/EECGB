def tup_string(tup1):
  str =  ''.join(tup1)
  return str