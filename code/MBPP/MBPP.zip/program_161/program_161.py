def remove_elements(list1, list2):
    result = [x for x in list1 if x not in list2]
    return result