from program_242 import count_charac
def test_1():
    assert count_charac("python programming")==18
def test_2():
    assert count_charac("language")==8
def test_3():
    assert count_charac("words")==5