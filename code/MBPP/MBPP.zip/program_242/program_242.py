def count_charac(str1):
 total = 0
 for i in str1:
    total = total + 1
 return total