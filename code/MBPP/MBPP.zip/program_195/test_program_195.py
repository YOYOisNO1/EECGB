from program_195 import first
def test_1():
    assert first([1,2,3,4,5,6,6],6,6) == 5
def test_2():
    assert first([1,2,2,2,3,2,2,4,2],2,9) == 1
def test_3():
    assert first([1,2,3],1,3) == 0