from program_19 import test_duplicate
def test_1():
    assert test_duplicate(([1,2,3,4,5]))==False
def test_2():
    assert test_duplicate(([1,2,3,4, 4]))==True
def test_3():
    assert test_duplicate([1,1,2,2,3,3,4,4,5])==True