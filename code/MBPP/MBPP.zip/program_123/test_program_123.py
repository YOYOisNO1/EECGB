from program_123 import amicable_numbers_sum
def test_1():
    assert amicable_numbers_sum(999)==504
def test_2():
    assert amicable_numbers_sum(9999)==31626
def test_3():
    assert amicable_numbers_sum(99)==0