import heapq
def larg_nnum(list1,n):
 largest=heapq.nlargest(n,list1)
 return largest