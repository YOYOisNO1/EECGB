from program_233 import lateralsuface_cylinder
def test_1():
    assert lateralsuface_cylinder(10,5)==314.15000000000003
def test_2():
    assert lateralsuface_cylinder(4,5)==125.66000000000001
def test_3():
    assert lateralsuface_cylinder(4,10)==251.32000000000002