from program_122 import smartNumber
def test_1():
    assert smartNumber(1) == 30
def test_2():
    assert smartNumber(50) == 273
def test_3():
    assert smartNumber(1000) == 2664