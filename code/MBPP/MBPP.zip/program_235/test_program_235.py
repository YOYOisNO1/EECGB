from program_235 import even_bit_set_number
def test_1():
    assert even_bit_set_number(10) == 10
def test_2():
    assert even_bit_set_number(20) == 30
def test_3():
    assert even_bit_set_number(30) == 30