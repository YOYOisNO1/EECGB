from program_246 import babylonian_squareroot
def test_1():
    assert babylonian_squareroot(10)==3.162277660168379
def test_2():
    assert babylonian_squareroot(2)==1.414213562373095
def test_3():
    assert babylonian_squareroot(9)==3.0