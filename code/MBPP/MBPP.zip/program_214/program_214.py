import math
def degree_radian(radian):
 degree = radian*(180/math.pi)
 return degree