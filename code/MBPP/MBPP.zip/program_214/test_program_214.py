from program_214 import degree_radian
def test_1():
    assert degree_radian(90)==5156.620156177409
def test_2():
    assert degree_radian(60)==3437.746770784939
def test_3():
    assert degree_radian(120)==6875.493541569878