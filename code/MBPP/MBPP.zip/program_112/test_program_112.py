from program_112 import perimeter
def test_1():
    assert perimeter(2,4) == 12
def test_2():
    assert perimeter(1,2) == 6
def test_3():
    assert perimeter(3,1) == 8