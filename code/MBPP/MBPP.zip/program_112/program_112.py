def perimeter(diameter,height) : 
    return 2*(diameter+height)  