from program_149 import longest_subseq_with_diff_one
def test_1():
    assert longest_subseq_with_diff_one([1, 2, 3, 4, 5, 3, 2], 7) == 6
def test_2():
    assert longest_subseq_with_diff_one([10, 9, 4, 5, 4, 8, 6], 7) == 3
def test_3():
    assert longest_subseq_with_diff_one([1, 2, 3, 2, 3, 7, 2, 1], 8) == 7