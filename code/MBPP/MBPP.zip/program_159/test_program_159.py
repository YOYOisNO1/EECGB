from program_159 import month_season
def test_1():
    assert month_season('January',4)==('winter')
def test_2():
    assert month_season('October',28)==('autumn')
def test_3():
    assert month_season('June',6)==('spring')