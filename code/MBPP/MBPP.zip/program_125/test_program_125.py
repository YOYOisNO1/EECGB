from program_125 import find_length
def test_1():
    assert find_length("11000010001", 11) == 6
def test_2():
    assert find_length("10111", 5) == 1
def test_3():
    assert find_length("11011101100101", 14) == 2 