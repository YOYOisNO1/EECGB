from program_220 import replace_max_specialchar
def test_1():
    assert replace_max_specialchar('Python language, Programming language.',2)==('Python:language: Programming language.')
def test_2():
    assert replace_max_specialchar('a b c,d e f',3)==('a:b:c:d e f')
def test_3():
    assert replace_max_specialchar('ram reshma,ram rahim',1)==('ram:reshma,ram rahim')