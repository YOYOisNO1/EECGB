def find_Volume(l,b,h) : 
    return ((l * b * h) / 2) 