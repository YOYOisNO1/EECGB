from program_14 import find_Volume
def test_1():
    assert find_Volume(10,8,6) == 240
def test_2():
    assert find_Volume(3,2,2) == 6
def test_3():
    assert find_Volume(1,2,1) == 1