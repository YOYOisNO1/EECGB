from program_116 import tuple_to_int
def test_1():
    assert tuple_to_int((1,2,3))==123
def test_2():
    assert tuple_to_int((4,5,6))==456
def test_3():
    assert tuple_to_int((5,6,7))==567