def tuple_to_int(nums):
    result = int(''.join(map(str,nums)))
    return result