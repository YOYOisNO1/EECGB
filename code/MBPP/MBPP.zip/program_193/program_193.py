def remove_tuple(test_tup):
  res = tuple(set(test_tup))
  return (res) 