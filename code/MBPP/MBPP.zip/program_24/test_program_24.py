from program_24 import binary_to_decimal
def test_1():
    assert binary_to_decimal(100) == 4
def test_2():
    assert binary_to_decimal(1011) == 11
def test_3():
    assert binary_to_decimal(1101101) == 109