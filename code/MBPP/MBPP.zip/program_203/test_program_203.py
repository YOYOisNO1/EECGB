from program_203 import hamming_Distance
def test_1():
    assert hamming_Distance(4,8) == 2
def test_2():
    assert hamming_Distance(2,4) == 2
def test_3():
    assert hamming_Distance(1,2) == 2