from program_15 import split_lowerstring
def test_1():
    assert split_lowerstring("AbCd")==['bC','d']
def test_2():
    assert split_lowerstring("Python")==['y', 't', 'h', 'o', 'n']
def test_3():
    assert split_lowerstring("Programming")==['r', 'o', 'g', 'r', 'a', 'm', 'm', 'i', 'n', 'g']