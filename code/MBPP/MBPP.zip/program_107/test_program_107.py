from program_107 import count_Hexadecimal
def test_1():
    assert count_Hexadecimal(10,15) == 6
def test_2():
    assert count_Hexadecimal(2,4) == 0
def test_3():
    assert count_Hexadecimal(15,16) == 1