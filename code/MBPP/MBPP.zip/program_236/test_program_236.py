from program_236 import No_of_Triangle
def test_1():
    assert No_of_Triangle(4,2) == 7
def test_2():
    assert No_of_Triangle(4,3) == 3
def test_3():
    assert No_of_Triangle(1,3) == -1