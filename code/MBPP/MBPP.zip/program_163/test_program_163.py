from program_163 import area_polygon
def test_1():
    assert area_polygon(4,20)==400.00000000000006
def test_2():
    assert area_polygon(10,15)==1731.1969896610804
def test_3():
    assert area_polygon(9,7)==302.90938549487214