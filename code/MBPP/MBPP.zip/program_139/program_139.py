def circle_circumference(r):
  perimeter=2*3.1415*r
  return perimeter