from program_139 import circle_circumference
def test_1():
    assert circle_circumference(10)==62.830000000000005
def test_2():
    assert circle_circumference(5)==31.415000000000003
def test_3():
    assert circle_circumference(4)==25.132