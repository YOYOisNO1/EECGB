from program_192 import check_String
def test_1():
    assert check_String('thishasboth29') == True
def test_2():
    assert check_String('python') == False
def test_3():
    assert check_String ('string') == False