from program_217 import first_Repeated_Char
def test_1():
    assert first_Repeated_Char("Google") == "o"
def test_2():
    assert first_Repeated_Char("data") == "a"
def test_3():
    assert first_Repeated_Char("python") == ''