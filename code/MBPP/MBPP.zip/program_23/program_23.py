def maximum_Sum(list1): 
    maxi = -100000
    for x in list1: 
        sum = 0 
        for y in x: 
            sum+= y      
        maxi = max(sum,maxi)     
    return maxi 