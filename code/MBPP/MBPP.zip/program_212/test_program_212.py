from program_212 import fourth_Power_Sum
def test_1():
    assert fourth_Power_Sum(2) == 17
def test_2():
    assert fourth_Power_Sum(4) == 354
def test_3():
    assert fourth_Power_Sum(6) == 2275