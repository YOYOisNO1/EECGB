def replace_blank(str1,char):
 str2 = str1.replace(' ', char)
 return str2