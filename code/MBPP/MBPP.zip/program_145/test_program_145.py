from program_145 import max_Abs_Diff
def test_1():
    assert max_Abs_Diff((2,1,5,3),4) == 4
def test_2():
    assert max_Abs_Diff((9,3,2,5,1),5) == 8
def test_3():
    assert max_Abs_Diff((3,2,1),3) == 2