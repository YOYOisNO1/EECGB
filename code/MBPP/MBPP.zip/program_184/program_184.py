def greater_specificnum(list,num):
 greater_specificnum=all(x >= num for x in list)
 return greater_specificnum