from program_184 import greater_specificnum
def test_1():
    assert greater_specificnum([220, 330, 500],200)==True
def test_2():
    assert greater_specificnum([12, 17, 21],20)==False
def test_3():
    assert greater_specificnum([1,2,3,4],10)==False