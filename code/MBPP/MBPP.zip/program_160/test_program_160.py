from program_160 import solution
def test_1():
    assert solution(2, 3, 7) == ('x = ', 2, ', y = ', 1)
def test_2():
    assert solution(4, 2, 7) == 'No solution'
def test_3():
    assert solution(1, 13, 17) == ('x = ', 4, ', y = ', 1)