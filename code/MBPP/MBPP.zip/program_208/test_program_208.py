from program_208 import is_decimal
def test_1():
    assert is_decimal('123.11') == True
def test_2():
    assert is_decimal('0.21') == True
def test_3():
    assert is_decimal('123.1214') == False