def specified_element(nums, N):
    result = [i[N] for i in nums]
    return result