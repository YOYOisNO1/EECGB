from program_150 import does_Contain_B
def test_1():
    assert does_Contain_B(1,7,3) == True
def test_2():
    assert does_Contain_B(1,-3,5) == False
def test_3():
    assert does_Contain_B(3,2,5) == False