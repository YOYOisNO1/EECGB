from program_198 import largest_triangle
def test_1():
    assert largest_triangle(4,2)==10.392304845413264
def test_2():
    assert largest_triangle(5,7)==4.639421805988064
def test_3():
    assert largest_triangle(9,1)==105.2220865598093