from program_21 import multiples_of_num
def test_1():
    assert multiples_of_num(4,3)== [3,6,9,12]
def test_2():
    assert multiples_of_num(2,5)== [5,10]
def test_3():
    assert multiples_of_num(9,2)== [2,4,6,8,10,12,14,16,18]