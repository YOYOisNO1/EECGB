def multiples_of_num(m,n): 
    multiples_of_num= list(range(n,(m+1)*n, n)) 
    return list(multiples_of_num)