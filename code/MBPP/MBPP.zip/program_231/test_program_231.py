from program_231 import max_sum
def test_1():
    assert max_sum([[1], [2,1], [3,3,2]], 3) == 6
def test_2():
    assert max_sum([[1], [1, 2], [4, 1, 12]], 3) == 15 
def test_3():
    assert max_sum([[2], [3,2], [13,23,12]], 3) == 28