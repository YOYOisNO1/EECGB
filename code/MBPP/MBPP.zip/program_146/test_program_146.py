from program_146 import ascii_value_string
def test_1():
    assert ascii_value_string("python")==112
def test_2():
    assert ascii_value_string("Program")==80
def test_3():
    assert ascii_value_string("Language")==76