def ascii_value_string(str1):
  for i in range(len(str1)):
   return ord(str1[i])