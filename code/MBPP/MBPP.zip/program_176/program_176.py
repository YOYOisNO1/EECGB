def perimeter_triangle(a,b,c):
  perimeter=a+b+c
  return perimeter