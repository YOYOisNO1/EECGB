from program_176 import perimeter_triangle
def test_1():
    assert perimeter_triangle(10,20,30)==60
def test_2():
    assert perimeter_triangle(3,4,5)==12
def test_3():
    assert perimeter_triangle(25,35,45)==105