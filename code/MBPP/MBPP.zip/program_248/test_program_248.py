from program_248 import harmonic_sum
def test_1():
    assert harmonic_sum(7) == 2.5928571428571425
def test_2():
    assert harmonic_sum(4) == 2.083333333333333
def test_3():
    assert harmonic_sum(19) == 3.547739657143682