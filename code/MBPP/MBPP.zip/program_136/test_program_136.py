from program_136 import cal_electbill
def test_1():
    assert cal_electbill(75)==246.25
def test_2():
    assert cal_electbill(265)==1442.75
def test_3():
    assert cal_electbill(100)==327.5