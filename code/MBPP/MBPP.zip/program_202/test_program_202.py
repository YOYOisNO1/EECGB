from program_202 import remove_even
def test_1():
    assert remove_even("python")==("pto")
def test_2():
    assert remove_even("program")==("porm")
def test_3():
    assert remove_even("language")==("lnug")