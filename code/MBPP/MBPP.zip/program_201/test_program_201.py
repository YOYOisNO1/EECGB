from program_201 import chkList
def test_1():
    assert chkList(['one','one','one']) == True
def test_2():
    assert chkList(['one','Two','Three']) == False
def test_3():
    assert chkList(['bigdata','python','Django']) == False