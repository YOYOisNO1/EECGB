def chkList(lst): 
    return len(set(lst)) == 1