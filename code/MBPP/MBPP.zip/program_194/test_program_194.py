from program_194 import octal_To_Decimal
def test_1():
    assert octal_To_Decimal(25) == 21
def test_2():
    assert octal_To_Decimal(30) == 24
def test_3():
    assert octal_To_Decimal(40) == 32