from program_183 import count_pairs
def test_1():
    assert count_pairs([1, 5, 3, 4, 2], 5, 3) == 2
def test_2():
    assert count_pairs([8, 12, 16, 4, 0, 20], 6, 4) == 5
def test_3():
    assert count_pairs([2, 4, 1, 3, 4], 5, 2) == 3