from program_162 import sum_series
def test_1():
    assert sum_series(6)==12
def test_2():
    assert sum_series(10)==30
def test_3():
    assert sum_series(9)==25