from program_191 import check_monthnumber
def test_1():
    assert check_monthnumber("February")==False
def test_2():
    assert check_monthnumber("June")==True
def test_3():
    assert check_monthnumber("April")==True