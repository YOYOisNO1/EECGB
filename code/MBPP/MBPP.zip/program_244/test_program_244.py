from program_244 import next_Perfect_Square
def test_1():
    assert next_Perfect_Square(35) == 36
def test_2():
    assert next_Perfect_Square(6) == 9
def test_3():
    assert next_Perfect_Square(9) == 16