from program_188 import prod_Square
def test_1():
    assert prod_Square(25) == False
def test_2():
    assert prod_Square(30) == False
def test_3():
    assert prod_Square(16) == True