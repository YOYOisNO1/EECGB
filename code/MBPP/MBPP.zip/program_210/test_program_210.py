from program_210 import is_allowed_specific_char
def test_1():
    assert is_allowed_specific_char("ABCDEFabcdef123450") == True
def test_2():
    assert is_allowed_specific_char("*&%@#!}{") == False
def test_3():
    assert is_allowed_specific_char("HELLOhowareyou98765") == True