def empty_dit(list1):
 empty_dit=all(not d for d in list1)
 return empty_dit