def add_lists(test_list, test_tup):
  res = tuple(list(test_tup) + test_list)
  return (res) 