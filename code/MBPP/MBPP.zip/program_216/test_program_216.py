from program_216 import check_subset_list
def test_1():
    assert check_subset_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],[[12, 18, 23, 25, 45], [7, 11, 19, 24, 28], [1, 5, 8, 18, 15, 16]])==False
def test_2():
    assert check_subset_list([[2, 3, 1], [4, 5], [6, 8]],[[4, 5], [6, 8]])==True
def test_3():
    assert check_subset_list([['a', 'b'], ['e'], ['c', 'd']],[['g']])==False