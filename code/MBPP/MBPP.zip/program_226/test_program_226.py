from program_226 import odd_values_string
def test_1():
    assert odd_values_string('abcdef') == 'ace'
def test_2():
    assert odd_values_string('python') == 'pto'
def test_3():
    assert odd_values_string('data') == 'dt'