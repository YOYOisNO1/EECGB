from program_1 import min_cost
# def test_1():
#     assert min_cost([[1, 2, 3], [4, 8, 2], [1, 5, 3]], 2, 2) == 8
# def test_2():
#     assert min_cost([[2, 3, 4], [5, 9, 3], [2, 6, 4]], 2, 2) == 12
# def test_3():
#     assert min_cost([[3, 4, 5], [6, 10, 4], [3, 7, 5]], 2, 2) == 16

def test_1():
    assert min_cost([[1]], 0, 0) == 1

def test_2():
    assert min_cost([[1, 2], [3, 4]], 1, 1) == 5

def test_3():
    assert min_cost([[1, 1, 1], [1, 1, 1], [1, 1, 1]], 2, 2) == 4

def test_4():
    assert min_cost([[5, 6, 8], [2, 3, 4], [7, 9, 10]], 2, 2) == 19

def test_5():
    assert min_cost([[10, 1, 5], [3, 9, 2], [8, 7, 4]], 2, 1) == 12

def test_6():
    assert min_cost([[1, 1, 1], [2, 2, 2], [3, 3, 3]], 2, 2) == 8

def test_7():
    assert min_cost([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 2, 2) == 21

def test_8():
    assert min_cost([[3, 3], [3, 3]], 1, 1) == 6

def test_9():
    assert min_cost([[0, 0, 0], [0, 0, 0], [0, 0, 0]], 2, 2) == 0

def test_10():
    assert min_cost([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]], 2, 3) == 27