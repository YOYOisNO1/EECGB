from program_121 import check_triplet
def test_1():
    assert check_triplet([2, 7, 4, 0, 9, 5, 1, 3], 8, 6, 0) == True
def test_2():
    assert check_triplet([1, 4, 5, 6, 7, 8, 5, 9], 8, 6, 0) == False
def test_3():
    assert check_triplet([10, 4, 2, 3, 5], 5, 15, 0) == True