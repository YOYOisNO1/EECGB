from program_223 import is_majority
from program_223 import binary_search
def test_1():
    assert is_majority([1, 2, 3, 3, 3, 3, 10], 7, 3) == True
def test_2():
    assert is_majority([1, 1, 2, 4, 4, 4, 6, 6], 8, 4) == False
def test_3():
    assert is_majority([1, 1, 1, 2, 2], 5, 1) == True