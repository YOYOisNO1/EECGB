from program_170 import sum_range_list
def test_1():
    assert sum_range_list( [2,1,5,6,8,3,4,9,10,11,8,12],8,10)==29
def test_2():
    assert sum_range_list( [2,1,5,6,8,3,4,9,10,11,8,12],5,7)==16
def test_3():
    assert sum_range_list( [2,1,5,6,8,3,4,9,10,11,8,12],7,10)==38