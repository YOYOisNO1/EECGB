from program_221 import first_even
def test_1():
    assert first_even ([1, 3, 5, 7, 4, 1, 6, 8]) == 4
def test_2():
    assert first_even([2, 3, 4]) == 2
def test_3():
    assert first_even([5, 6, 7]) == 6