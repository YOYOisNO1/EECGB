from program_22 import find_first_duplicate
def test_1():
    assert find_first_duplicate(([1, 2, 3, 4, 4, 5]))==4
def test_2():
    assert find_first_duplicate([1, 2, 3, 4])==-1
def test_3():
    assert find_first_duplicate([1, 1, 2, 3, 3, 2, 2])==1