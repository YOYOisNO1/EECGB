from program_187 import longest_common_subsequence
def test_1():
    assert longest_common_subsequence("AGGTAB" , "GXTXAYB", 6, 7) == 4
def test_2():
    assert longest_common_subsequence("ABCDGH" , "AEDFHR", 6, 6) == 3
def test_3():
    assert longest_common_subsequence("AXYT" , "AYZX", 4, 4) == 2