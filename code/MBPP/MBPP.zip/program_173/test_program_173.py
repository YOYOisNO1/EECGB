from program_173 import remove_splchar
def test_1():
    assert remove_splchar('python  @#&^%$*program123')==('pythonprogram123')
def test_2():
    assert remove_splchar('python %^$@!^&*()  programming24%$^^()    language')==('pythonprogramming24language')
def test_3():
    assert remove_splchar('python   ^%&^()(+_)(_^&67)                  program')==('python67program')