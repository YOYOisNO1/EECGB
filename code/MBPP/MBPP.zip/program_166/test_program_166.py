from program_166 import find_even_Pair
def test_1():
    assert find_even_Pair([5,4,7,2,1],5) == 4
def test_2():
    assert find_even_Pair([7,2,8,1,0,5,11],7) == 9
def test_3():
    assert find_even_Pair([1,2,3],3) == 1