from program_204 import count
def test_1():
    assert count("abcc","c") == 2
def test_2():
    assert count("ababca","a") == 3
def test_3():
    assert count("mnmm0pm","m") == 4