def sort_matrix(M):
    result = sorted(M, key=sum)
    return result