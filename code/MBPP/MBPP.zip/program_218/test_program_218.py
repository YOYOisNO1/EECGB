from program_218 import min_Operations
def test_1():
    assert min_Operations(2,4) == 1
def test_2():
    assert min_Operations(4,10) == 4
def test_3():
    assert min_Operations(1,4) == 3