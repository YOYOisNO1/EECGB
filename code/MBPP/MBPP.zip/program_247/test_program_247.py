from program_247 import lps
def test_1():
    assert lps("TENS FOR TENS") == 5 
def test_2():
    assert lps("CARDIO FOR CARDS") == 7
def test_3():
    assert lps("PART OF THE JOURNEY IS PART") == 9 