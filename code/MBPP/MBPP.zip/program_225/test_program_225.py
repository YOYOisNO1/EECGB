from program_225 import find_Min
def test_1():
    assert find_Min([1,2,3,4,5],0,4) == 1
def test_2():
    assert find_Min([4,6,8],0,2) == 4
def test_3():
    assert find_Min([2,3,5,7,9],0,4) == 2