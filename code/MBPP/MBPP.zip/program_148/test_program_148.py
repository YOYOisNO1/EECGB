from program_148 import sum_digits_single
from program_148 import closest
from program_148 import sum_digits_twoparts
def test_1():
    assert sum_digits_twoparts(35)==17
def test_2():
    assert sum_digits_twoparts(7)==7
def test_3():
    assert sum_digits_twoparts(100)==19