from program_167 import next_Power_Of_2
def test_1():
    assert next_Power_Of_2(0) == 1
def test_2():
    assert next_Power_Of_2(5) == 8
def test_3():
    assert next_Power_Of_2(17) == 32