def parabola_focus(a, b, c): 
  focus= (((-b / (2 * a)),(((4 * a * c) - (b * b) + 1) / (4 * a))))
  return focus