from program_11 import remove_Occ
def test_1():
    assert remove_Occ("hello","l") == "heo"
def test_2():
    assert remove_Occ("abcda","a") == "bcd"
def test_3():
    assert remove_Occ("PHP","P") == "H"