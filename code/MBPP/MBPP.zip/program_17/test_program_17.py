from program_17 import square_perimeter
def test_1():
    assert square_perimeter(10)==40
def test_2():
    assert square_perimeter(5)==20
def test_3():
    assert square_perimeter(4)==16