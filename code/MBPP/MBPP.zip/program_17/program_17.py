def square_perimeter(a):
  perimeter=4*a
  return perimeter