from program_138 import is_Sum_Of_Powers_Of_Two
def test_1():
    assert is_Sum_Of_Powers_Of_Two(10) == True
def test_2():
    assert is_Sum_Of_Powers_Of_Two(7) == False
def test_3():
    assert is_Sum_Of_Powers_Of_Two(14) == True