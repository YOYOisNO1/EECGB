from program_234 import volume_cube
def test_1():
    assert volume_cube(3)==27
def test_2():
    assert volume_cube(2)==8
def test_3():
    assert volume_cube(5)==125