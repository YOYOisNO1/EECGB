from program_165 import count_char_position
def test_1():
    assert count_char_position("xbcefg") == 2
def test_2():
    assert count_char_position("ABcED") == 3
def test_3():
    assert count_char_position("AbgdeF") == 5