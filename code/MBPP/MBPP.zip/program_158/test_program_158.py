from program_158 import min_Ops
def test_1():
    assert min_Ops([2,2,2,2],4,3) == 0
def test_2():
    assert min_Ops([4,2,6,8],4,3) == -1
def test_3():
    assert min_Ops([21,33,9,45,63],5,6) == 24