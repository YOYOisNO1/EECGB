from program_224 import count_Set_Bits
def test_1():
    assert count_Set_Bits(2) == 1
def test_2():
    assert count_Set_Bits(4) == 1
def test_3():
    assert count_Set_Bits(6) == 2