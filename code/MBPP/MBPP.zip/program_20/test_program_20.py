from program_20 import is_woodall
def test_1():
    assert is_woodall(383) == True
def test_2():
    assert is_woodall(254) == False
def test_3():
    assert is_woodall(200) == False