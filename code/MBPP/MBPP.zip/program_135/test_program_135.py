from program_135 import hexagonal_num
def test_1():
    assert hexagonal_num(10) == 190
def test_2():
    assert hexagonal_num(5) == 45
def test_3():
    assert hexagonal_num(7) == 91