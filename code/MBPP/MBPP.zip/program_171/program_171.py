import math
def perimeter_pentagon(a):
  perimeter=(5*a)
  return perimeter