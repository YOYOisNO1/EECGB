from program_171 import perimeter_pentagon
def test_1():
    assert perimeter_pentagon(5)==25
def test_2():
    assert perimeter_pentagon(10)==50
def test_3():
    assert perimeter_pentagon(15)==75