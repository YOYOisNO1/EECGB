from program_189 import first_Missing_Positive
def test_1():
    assert first_Missing_Positive([1,2,3,-1,5],5) == 4
def test_2():
    assert first_Missing_Positive([0,-1,-2,1,5,8],6) == 2
def test_3():
    assert first_Missing_Positive([0,1,2,5,-8],5) == 3