from program_199 import highest_Power_of_2
def test_1():
    assert highest_Power_of_2(10) == 8
def test_2():
    assert highest_Power_of_2(19) == 16
def test_3():
    assert highest_Power_of_2(32) == 32