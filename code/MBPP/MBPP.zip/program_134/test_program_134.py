from program_134 import check_last
def test_1():
    assert check_last([5,7,10],3,1) == "ODD"
def test_2():
    assert check_last([2,3],2,3) == "EVEN"
def test_3():
    assert check_last([1,2,3],3,1) == "ODD"