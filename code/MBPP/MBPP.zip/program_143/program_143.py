def find_lists(Input): 
	if isinstance(Input, list): 
		return 1
	else: 
		return len(Input) 