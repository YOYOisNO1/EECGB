from program_238 import number_of_substrings
def test_1():
    assert number_of_substrings("abc") == 6
def test_2():
    assert number_of_substrings("abcd") == 10
def test_3():
    assert number_of_substrings("abcde") == 15