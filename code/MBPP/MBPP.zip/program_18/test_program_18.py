from program_18 import str_to_list
from program_18 import lst_to_string
from program_18 import get_char_count_array
from program_18 import remove_dirty_chars
def test_1():
    assert remove_dirty_chars("probasscurve", "pros") == 'bacuve'
def test_2():
    assert remove_dirty_chars("digitalindia", "talent") == 'digiidi'
def test_3():
    assert remove_dirty_chars("exoticmiles", "toxic") == 'emles' 