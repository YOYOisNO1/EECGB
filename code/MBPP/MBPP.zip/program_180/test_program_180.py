from program_180 import distance_lat_long
def test_1():
    assert distance_lat_long(23.5,67.5,25.5,69.5)==12179.372041317429
def test_2():
    assert distance_lat_long(10.5,20.5,30.5,40.5)==6069.397933300514
def test_3():
    assert distance_lat_long(10,20,30,40)==6783.751974994595