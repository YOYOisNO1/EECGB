from program_144 import sum_Pairs
def test_1():
    assert sum_Pairs([1,8,9,15,16],5) == 74
def test_2():
    assert sum_Pairs([1,2,3,4],4) == 10
def test_3():
    assert sum_Pairs([1,2,3,4,5,7,9,11,14],9) == 188