from program_190 import count_Intgral_Points
def test_1():
    assert count_Intgral_Points(1,1,4,4) == 4
def test_2():
    assert count_Intgral_Points(1,2,1,2) == 1
def test_3():
    assert count_Intgral_Points(4,2,6,4) == 1