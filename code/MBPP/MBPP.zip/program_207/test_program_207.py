from program_207 import find_longest_repeating_subseq
def test_1():
    assert find_longest_repeating_subseq("AABEBCDD") == 3
def test_2():
    assert find_longest_repeating_subseq("aabb") == 2
def test_3():
    assert find_longest_repeating_subseq("aab") == 1