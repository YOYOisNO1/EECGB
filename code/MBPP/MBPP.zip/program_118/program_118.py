def string_to_list(string): 
    lst = list(string.split(" ")) 
    return lst