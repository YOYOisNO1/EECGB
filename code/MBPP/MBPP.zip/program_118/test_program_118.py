from program_118 import string_to_list
def test_1():
    assert string_to_list("python programming")==['python','programming']
def test_2():
    assert string_to_list("lists tuples strings")==['lists','tuples','strings']
def test_3():
    assert string_to_list("write a program")==['write','a','program']