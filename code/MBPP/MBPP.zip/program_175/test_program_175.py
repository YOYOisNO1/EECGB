from program_175 import is_valid_parenthese
def test_1():
    assert is_valid_parenthese("(){}[]")==True
def test_2():
    assert is_valid_parenthese("()[{)}")==False
def test_3():
    assert is_valid_parenthese("()")==True