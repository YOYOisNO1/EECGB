from program_164 import divSum
from program_164 import areEquivalent
def test_1():
    assert areEquivalent(36,57) == False
def test_2():
    assert areEquivalent(2,4) == False
def test_3():
    assert areEquivalent(23,47) == True