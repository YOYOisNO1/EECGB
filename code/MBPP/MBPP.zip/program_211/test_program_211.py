from program_211 import count_Num
def test_1():
    assert count_Num(2) == 1
def test_2():
    assert count_Num(3) == 2
def test_3():
    assert count_Num(1) == 1