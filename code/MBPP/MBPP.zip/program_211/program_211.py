def count_Num(n): 
    if (n == 1): 
        return 1
    count = pow(2,n - 2) 
    return count 