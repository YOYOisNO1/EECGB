from program_131 import reverse_vowels
def test_1():
    assert reverse_vowels("Python") == "Python"
def test_2():
    assert reverse_vowels("USA") == "ASU"
def test_3():
    assert reverse_vowels("ab") == "ab"