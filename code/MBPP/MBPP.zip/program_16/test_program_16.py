from program_16 import text_lowercase_underscore
def test_1():
    assert text_lowercase_underscore("aab_cbbbc")==('Found a match!')
def test_2():
    assert text_lowercase_underscore("aab_Abbbc")==('Not matched!')
def test_3():
    assert text_lowercase_underscore("Aaab_abbbc")==('Not matched!')