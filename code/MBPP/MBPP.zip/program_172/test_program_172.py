from program_172 import count_occurance
def test_1():
    assert count_occurance("letstdlenstdporstd") == 3
def test_2():
    assert count_occurance("truststdsolensporsd") == 1
def test_3():
    assert count_occurance("makestdsostdworthit") == 2