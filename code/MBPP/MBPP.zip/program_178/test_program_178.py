from program_178 import string_literals
def test_1():
    assert string_literals(['language'],'python language')==('Matched!')
def test_2():
    assert string_literals(['program'],'python language')==('Not Matched!')
def test_3():
    assert string_literals(['python'],'programming language')==('Not Matched!')