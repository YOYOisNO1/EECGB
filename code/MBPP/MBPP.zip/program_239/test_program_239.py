from program_239 import get_total_number_of_sequences
def test_1():
    assert get_total_number_of_sequences(10, 4) == 4
def test_2():
    assert get_total_number_of_sequences(5, 2) == 6
def test_3():
    assert get_total_number_of_sequences(16, 3) == 84