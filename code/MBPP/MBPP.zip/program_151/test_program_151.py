from program_151 import gcd
from program_151 import is_coprime
def test_1():
    assert is_coprime(17,13) == True
def test_2():
    assert is_coprime(15,21) == False
def test_3():
    assert is_coprime(25,45) == False