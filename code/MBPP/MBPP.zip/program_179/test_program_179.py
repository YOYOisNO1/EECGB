from program_179 import is_num_keith
def test_1():
    assert is_num_keith(14) == True
def test_2():
    assert is_num_keith(12) == False
def test_3():
    assert is_num_keith(197) == True