def replace_list(list1,list2):
 list1[-1:] = list2
 replace_list=list1
 return replace_list
