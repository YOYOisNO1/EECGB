from program_109 import odd_Equivalent
def test_1():
    assert odd_Equivalent("011001",6) == 3
def test_2():
    assert odd_Equivalent("11011",5) == 4
def test_3():
    assert odd_Equivalent("1010",4) == 2