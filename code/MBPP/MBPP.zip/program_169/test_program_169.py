from program_169 import get_pell
def test_1():
    assert get_pell(4) == 12
def test_2():
    assert get_pell(7) == 169
def test_3():
    assert get_pell(8) == 408