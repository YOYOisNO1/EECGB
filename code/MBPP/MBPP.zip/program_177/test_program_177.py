from program_177 import answer
def test_1():
    assert answer(3,8) == (3,6)
def test_2():
    assert answer(2,6) == (2,4)
def test_3():
    assert answer(1,3) == (1,2)