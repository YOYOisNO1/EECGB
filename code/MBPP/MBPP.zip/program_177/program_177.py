def answer(L,R): 
    if (2 * L <= R): 
        return (L ,2*L)
    else: 
        return (-1) 