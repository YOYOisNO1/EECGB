from program_101 import kth_element
def test_1():
    assert kth_element([12,3,5,7,19], 5, 2) == 3
def test_2():
    assert kth_element([17,24,8,23], 4, 3) == 8
def test_3():
    assert kth_element([16,21,25,36,4], 5, 4) == 36