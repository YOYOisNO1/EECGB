def count(lst):   
    return sum(lst) 