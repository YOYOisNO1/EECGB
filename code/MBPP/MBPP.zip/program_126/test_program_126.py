from program_126 import sum
def test_1():
    assert sum(10,15) == 6
def test_2():
    assert sum(100,150) == 93
def test_3():
    assert sum(4,6) == 3