from program_155 import even_bit_toggle_number
def test_1():
    assert even_bit_toggle_number(10) == 0
def test_2():
    assert even_bit_toggle_number(20) == 30
def test_3():
    assert even_bit_toggle_number(30) == 20