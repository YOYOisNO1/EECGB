from program_186 import check_literals
def test_1():
    assert check_literals('The quick brown fox jumps over the lazy dog.',['fox']) == 'Matched!'
def test_2():
    assert check_literals('The quick brown fox jumps over the lazy dog.',['horse']) == 'Not Matched!'
def test_3():
    assert check_literals('The quick brown fox jumps over the lazy dog.',['lazy']) == 'Matched!'