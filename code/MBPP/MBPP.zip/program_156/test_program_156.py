from program_156 import tuple_int_str
def test_1():
    assert tuple_int_str((('333', '33'), ('1416', '55')))==((333, 33), (1416, 55))
def test_2():
    assert tuple_int_str((('999', '99'), ('1000', '500')))==((999, 99), (1000, 500))
def test_3():
    assert tuple_int_str((('666', '66'), ('1500', '555')))==((666, 66), (1500, 555))