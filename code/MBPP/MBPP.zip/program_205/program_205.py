def inversion_elements(test_tup):
  res = tuple(list(map(lambda x: ~x, list(test_tup))))
  return (res) 