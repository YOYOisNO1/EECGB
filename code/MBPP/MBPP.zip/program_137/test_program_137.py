from program_137 import zero_count
def test_1():
    assert zero_count([0, 1, 2, -1, -5, 6, 0, -3, -2, 3, 4, 6, 8])==0.15
def test_2():
    assert zero_count([2, 1, 2, -1, -5, 6, 4, -3, -2, 3, 4, 6, 8])==0.00
def test_3():
    assert zero_count([2, 4, -6, -9, 11, -12, 14, -5, 17])==0.00