from program_181 import common_prefix_util
from program_181 import common_prefix
def test_1():
    assert common_prefix(["tablets", "tables", "taxi", "tamarind"], 4) == 'ta'
def test_2():
    assert common_prefix(["apples", "ape", "april"], 3) == 'ap'
def test_3():
    assert common_prefix(["teens", "teenager", "teenmar"], 3) == 'teen'