

def unique(l: list):
    
    return sorted(list(set(l)))
