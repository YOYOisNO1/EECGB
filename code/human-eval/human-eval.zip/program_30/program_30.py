

def get_positive(l: list):
    
    return [e for e in l if e > 0]
