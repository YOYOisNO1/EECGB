from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # Sort the list of numbers
    numbers.sort()

    # Calculate first difference
    first_diff = 0

    # Look for the first difference larger than threshold
    for i, num in enumerate(numbers):
        if num > threshold:
            break

        first_diff += (numbers[i + 1] - numbers[i])

    # Look for the second difference larger than threshold
    for i, num in enumerate(numbers):
        if num > threshold:
            break

        second_diff = (numbers[i + 2] - numbers[i + 1])

    # Look for the third difference larger than threshold
    for i, num in enumerate(numbers):
        if num > threshold:
            break

        third_diff = (numbers[i + 3] - numbers[i + 2])

    # Check that the first and second diffs are smaller than the third diff.
    # If not, the first diff is the largest.
    if first_diff > third_diff:
        return False
    elif first_diff == third_diff:
        return True
    else:
        return False

