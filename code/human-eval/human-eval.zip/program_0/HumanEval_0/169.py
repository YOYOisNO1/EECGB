from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if len(numbers) == 0:
        return False

    if threshold == 0.0:
        return False

    sorted_numbers = sorted(numbers)
    sorted_numbers_with_threshold = sorted([n for n in numbers if abs(n - n[0]) < threshold],
                                          key=abs)

    # number of elements that are closer to each other than threshold
    num_close_elements = 0

    for n in sorted_numbers_with_threshold:
        if abs(n - n[0]) > threshold:
            num_close_elements += 1

    return num_close_elements == 0

