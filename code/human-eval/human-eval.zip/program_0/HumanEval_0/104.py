from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # Sort the list of numbers in ascending order
    sorted_numbers = sorted(numbers)

    # Iterate through all the pairs of numbers
    for current_index, current_number in enumerate(sorted_numbers):
        next_index = current_index + 1

        # Iterate through all the numbers before current_index
        for previous_index in range(current_index - 1):
            previous_number = sorted_numbers[previous_index]

            # Check if current number is closer to previous number than to current_number
            if (
                current_number - previous_number < threshold
                and current_number - current_index > threshold
            ):
                return True

    # At this point we have checked if all the numbers are closer to each other than given
    # threshold. So return False
    return False

