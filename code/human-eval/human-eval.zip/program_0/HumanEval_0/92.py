from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if len(numbers) < 2:
        return False

    x, y = numbers[0], numbers[-1]
    if x > y:
        x, y = y, x

    # Find the smallest difference between any two elements
    minimum = float('inf')

    # If any element is closest to 0.0, check if there is one at least a tenth of the
    #   distance of all other elements to zero.
    for i in range(1, len(numbers)):
        if numbers[i] - x < 0.1 * minimum:
            minimum = numbers[i] - x

    return minimum < threshold

