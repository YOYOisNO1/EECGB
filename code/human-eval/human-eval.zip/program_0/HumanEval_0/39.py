from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if numbers is None:
        return False

    size = len(numbers)
    minimum = numbers[0]
    maximum = numbers[-1]

    # find the closest pair of numbers
    min_index = None
    min_value = None
    for index, value in enumerate(numbers):
        if index == size / 2:
            continue
        if value < minimum:
            min_value = value
            min_index = index
        elif value > maximum:
            max_index = index
            max_value = value
        else:
            continue
        if min_value > max_value:
            if min_index == max_index:
                return False
            min_value = min_value + threshold
        elif max_index == min_index:
            if min_value > max_value:
                return False
            max_value = max_value + threshold
        elif min_index > max_index:
            return False

    return True

