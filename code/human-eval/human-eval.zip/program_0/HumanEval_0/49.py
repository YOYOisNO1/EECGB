from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    def dists(numbers: List[float]) -> List[float]:
        """ Return distances between given numbers. """
        if not numbers:
            return numbers
        if len(numbers) > 1:
            s = list(numbers)
            m = len(s)
        else:
            s = numbers[0]
            m = 1
        if m == 1:
            return [numbers[0]]
        return [numbers[0]] + (
            dists(numbers[:m]) +
            [0 for _ in range(m - 1)]
        )

    return all(numbers[i] - numbers[i + 1] < threshold for i in range(m - 1))

