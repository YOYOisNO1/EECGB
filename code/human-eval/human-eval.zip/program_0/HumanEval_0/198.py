from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # Python 3:
    # https://stackoverflow.com/questions/26931901/how-to-make-python-not-eval-a-list-to-a-string/
    # https://stackoverflow.com/questions/50355979/how-to-check-if-a-list-is-sorted-or-not/
    # https://stackoverflow.com/questions/35632494/how-to-make-python-not-eval-a-list-to-a-string/
    # Python 2:
    # https://stackoverflow.com/questions/594812/how-do-i-check-if-a-list-is-sorted/
    # https://stackoverflow.com/questions/16829826/how-to-make-python-not-eval-a-list-to-a-string-in-python-2/
    if numbers is None or len(numbers) == 0:
        return True
    else:
        # Find first and last numbers
        first = numbers[0]
        last = numbers[-1]
        # We will store the maximum distance between each two numbers
        distances = []
        # First pass: use O(n) algorithm to find the maximum distance between first and last
        for n in numbers[1:]:
            # If first and last are equal, we are done
            if n == first or n == last:
                return True
            # Otherwise, we can save some time and add this distance to the maximum so far
            distances.append(abs(n - first))
            # And we have to skip the first
