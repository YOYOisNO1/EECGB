from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    counter_1 = 0
    counter_2 = 0

    for num1, num2 in zip(numbers, numbers[1:]):
        if num1 < num2:
            counter_1 += 1

        if num2 > num1:
            counter_2 += 1

    return counter_1 + counter_2 < 2

