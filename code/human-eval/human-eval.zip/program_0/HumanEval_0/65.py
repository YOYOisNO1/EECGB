from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # Check if there are numbers closer to each other than given threshold
    distances = []
    for number in numbers:
        # Number of numbers must be less than or equal to 2
        if len(numbers) < 2:
            return False
        # Get min distance
        min_distance = min(numbers, key=lambda number: abs(number - number[0]))
        # Find closest one
        closest_number = numbers[0]
        distances.append(abs(number - closest_number))
        # Check if the distance is closer than given threshold
        if abs(number - closest_number) < threshold:
            return True
    return False

