from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if len(numbers) == 0:
        return False
    threshold_sum = sum(threshold for _ in numbers)
    if threshold_sum > 0:
        threshold_max = max(threshold_sum, numbers[0])
        threshold_min = min(threshold_sum, numbers[0])
        for i, n in enumerate(numbers):
            for j, n in enumerate(numbers):
                if i == j and n <= threshold_max and n >= threshold_min:
                    return True
    return False

