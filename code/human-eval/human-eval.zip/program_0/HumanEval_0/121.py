from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # TODO: implement a more efficient algorithm
    #        1. start with the last element
    #        2. if we're not at the end of the list, start with the next element and continue from 1.
    #        3. if we're at the end of the list, there are no more elements to look at and return True.
    #        4. if we're not at the end of the list, continue from 1.
    #        5. if we're at the end of the list, there are no more elements to look at and return False.
    #        6. for every other element, compare it to the current element, see if it is closer.
    #             if it is, continue from 1.
    #        7. if there are no more elements, return True.
    #        8. if there are no more elements, return False.

    # TODO: implement a more efficient algorithm
    #        9. start with the last element
    #        10. if we're not at the end of the list, start with the next element and continue from 9.
    #        11. if we're at the end of the list, there are no more elements to look at and return True.
    #        12. if we're not at the end of the list, continue from 9.
    #        13. if we're at the end of the list, there are no more elements to look at and return False.
    #        14. for every other element, compare it to the current element, see if it is closer.
    #             if it is, continue from 9.
    #        15. if
