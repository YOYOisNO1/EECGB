from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    threshold_abs = abs(threshold)
    if len(numbers) <= 1:
        return False

    if not numbers[0] >= 0.0:
        raise ValueError("List of numbers must have at least one positive element")

    # is the first element really in interval?
    if numbers[0] >= threshold_abs:
        return True

    if not numbers[0] <= threshold_abs:
        return False

    # Look at the second element
    if not numbers[1] >= 0.0:
        raise ValueError("List of numbers must have at least one positive element")

    if not numbers[1] <= threshold_abs:
        return False

    if not numbers[1] <= numbers[0]:
        return False

    # Look at the third element
    if not numbers[2] >= 0.0:
        raise ValueError("List of numbers must have at least one positive element")

    if not numbers[2] <= threshold_abs:
        return False

    if not numbers[2] <= numbers[1]:
        return False

    if not numbers[2] <= numbers[0]:
        return False

    # Look at the fourth element
    if not numbers[3] >= 0.0:
        raise ValueError("List of numbers must have at least one positive element")

    if not numbers[3] <= threshold_abs:
        return False

    if not numbers[3] <= numbers[2]:
        return False

    if not numbers[3] <= numbers[1]:
        return False

    if not numbers[3] <= numbers[0]:
        return False

    # Look at the
