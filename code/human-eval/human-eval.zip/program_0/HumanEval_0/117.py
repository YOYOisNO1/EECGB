from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if len(numbers) < 2:
        return True

    if numbers[0] > numbers[-1]:
        numbers.reverse()

    max_diff = 0.0
    for i, number in enumerate(numbers):
        if number > numbers[i - 1]:
            # get the difference in absolute value
            diff = abs(number - numbers[i - 1])
        else:
            diff = abs(number - numbers[i])

        if i < len(numbers) - 1 and diff < threshold:
            return True

        max_diff = max(max_diff, diff)

    return not max_diff > threshold

