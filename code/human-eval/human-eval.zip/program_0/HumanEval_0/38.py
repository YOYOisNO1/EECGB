from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    nums_ranges = zip(*[range(n) for n in numbers])
    for i in nums_ranges:
        for j in nums_ranges:
            if i[1] < j[1]:
                if abs(i[0] - j[0]) < abs(i[1] - j[1]):
                    return True
    return False

