from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # get absolute difference
    diffs = [abs(x - y) for x, y in zip(numbers, numbers[1:])]
    # find difference threshold
    diff_threshold = min(diffs)
    # keep track of the first element that is closer to second
    closer = None
    for x in numbers:
        if diffs[0] < diff_threshold:
            closer = x
            diffs[0] = abs(x - closer)
    return closer!= None and diffs[0] < diff_threshold
