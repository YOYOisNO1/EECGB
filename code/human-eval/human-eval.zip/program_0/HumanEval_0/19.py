from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # 1. Check if both numbers are smaller than given threshold
    if len(numbers) == 2:
        if numbers[0] < numbers[1] and numbers[0] < threshold:
            return True

    # 2. Check if one number is smaller and another is larger
    if len(numbers) == 2:
        if numbers[0] < threshold and numbers[1] > threshold:
            return True

    # 3. Check if one number is larger and another is smaller
    if len(numbers) == 2:
        if numbers[0] > threshold and numbers[1] < threshold:
            return True

    # 4. Check if any other combination of two numbers is within given threshold
    else:
        for i in range(len(numbers)):
            if numbers[i] < threshold and numbers[i + 1] > threshold:
                return True

    return False

