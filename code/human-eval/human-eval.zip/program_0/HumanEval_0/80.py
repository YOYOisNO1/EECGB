from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    def get_closest_to_threshold(a, b, threshold):
        return abs(a - b) < threshold

    if not numbers:
        return True

    def get_closest_elements(numbers, threshold):
        a = numbers[0]
        b = numbers[-1]

        for i in range(1, len(numbers) - 1):
            if numbers[i] < numbers[i - 1]:
                continue

            if get_closest_to_threshold(a, numbers[i], threshold):
                return True
            elif get_closest_to_threshold(b, numbers[i], threshold):
                return True

        return False

    return get_closest_elements(numbers, threshold)

