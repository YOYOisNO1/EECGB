from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    numbers.sort(reverse=True)
    sorted_numbers = list(numbers)
    sorted_numbers.sort()
    # Cut the list in half and put it on each side of the threshold
    split_numbers = list(numbers)
    split_numbers.extend(sorted_numbers)
    split_numbers.extend(sorted_numbers[::-1])
    # For each of the halves calculate the minimum difference in numbers
    # to see if they are closer to each other than threshold
    for i in range(len(split_numbers)):
        # In the first half
        if i == 0:
            for j in range(len(split_numbers)):
                if abs(split_numbers[j] - split_numbers[j + 1]) < threshold:
                    return True
        # In the second half
        else:
            for j in range(len(split_numbers)):
                if abs(split_numbers[j] - split_numbers[j - 1]) < threshold:
                    return True
    return False

