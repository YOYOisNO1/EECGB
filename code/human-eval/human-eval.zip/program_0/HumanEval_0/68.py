from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if len(numbers) == 0:
        return True

    min_distance = math.inf

    for i, n in enumerate(numbers):
        if n > threshold:
            continue
        if n < min_distance:
            min_distance = n
            idx = i
            continue

        if min_distance < math.fabs(n - numbers[i - 1]):
            min_distance = math.fabs(n - numbers[i - 1])

    return min_distance < threshold
