from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if not numbers:
        return True

    threshold_diff = abs(numbers[0] - numbers[-1])
    last_diff = threshold_diff
    for i, num in enumerate(numbers):
        cur_diff = abs(numbers[i] - numbers[i-1])
        if cur_diff < last_diff:
            last_diff = cur_diff
            if i == 0:
                return True
    return False

