from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    num_lens = len(numbers)
    if num_lens < 2:
        return False
    distance = numbers[0] - numbers[1]
    max_distance = max(distance, abs(numbers[-1] - numbers[-2]))
    for i in range(2, num_lens):
        distance = distance * numbers[i] - numbers[i-1]
        if distance < threshold:
            return True
    return False

