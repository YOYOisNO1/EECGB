from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    num_close = [1, 1, 2, 3, 4, 5]
    closest_to_zero = [0, 0, 0, 0, 0, 0]
    for i in num_close:
        if abs(i - numbers[i]) < threshold:
            closest_to_zero[i] = 1
    return closest_to_zero
