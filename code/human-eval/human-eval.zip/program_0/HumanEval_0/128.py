from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    try:
        # Try to compute a distance between each two numbers
        # It is defined as euclidean distance between two points
        # Here, the number of points is twice as the size of the list, so it should be
        # numpy.sqrt(numpy.sum(numpy.square(numbers - numpy.array([]))))
        distances = numpy.square(numbers - numpy.array([]))
        for i in range(0, len(distances), 2):
            if distances[i:i + 2] > threshold:
                return True
        return False
    except:
        raise TypeError("numbers must be a list")

