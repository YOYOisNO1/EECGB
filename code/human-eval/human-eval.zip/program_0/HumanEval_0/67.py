from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    assert 0.0 <= threshold, "threshold must be non-negative"
    threshold = max(threshold, 0.0)
    nums = [float(i) for i in numbers]
    nums = sorted(nums)
    dist = 0.0
    for i in range(len(nums) - 1):
        if nums[i] - nums[i + 1] <= threshold:
            dist += nums[i] - nums[i + 1]
        else:
            break
    return dist < threshold

