from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # Check if any two elements in the list are closer than given threshold
    if len(numbers) == 2:
        # Check if the distance between the two elements is smaller than given threshold
        return numbers[0] - numbers[1] < threshold
    else:
        # Check if any element in the list is closer than given threshold
        min_distance = numbers[0]
        for number in numbers:
            if number - min_distance < threshold:
                return True
        return False

