from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    sorted_numbers = sorted(numbers)

    if len(numbers) < 2:
        return True

    threshold_distance = abs(threshold - numbers[0])
    distance_index = 0

    for current_number, next_number in zip(sorted_numbers, sorted_numbers[1:]):
        if abs(threshold_distance - (current_number - numbers[distance_index])) < abs(threshold_distance - (next_number - numbers[distance_index])):
            distance_index += 1
            threshold_distance = abs(threshold - numbers[distance_index])
            if distance_index == len(numbers):
                return True

    return False

