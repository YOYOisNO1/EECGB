from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    difference_l1 = len(numbers) - 1
    difference_l2 = numbers[-1] - numbers[0]
    numbers_sorted = [numbers[0], numbers[1],..., numbers[-2], numbers[-1]]
    first_number = numbers[0]
    last_number = numbers[-1]

    # check if all numbers are in same range
    if last_number - first_number > threshold:
        return False

    # if we have closed loop - check if it is longer than threshold
    if numbers_sorted[-2] - numbers_sorted[-1] > threshold:
        return True

    # if we have at least 2 numbers - check if they are close to each other
    if difference_l1 > threshold and difference_l2 > threshold:
        return True

    return False

