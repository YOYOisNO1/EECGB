

def flip_case(string: str) -> str:
    
    return string.swapcase()
