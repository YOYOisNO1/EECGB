

def truncate_number(number: float) -> float:
    
    return number % 1.0
